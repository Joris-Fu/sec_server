from django.conf.urls import url
from queryAPI import views
urlpatterns = [
    url(r'^api/get/node/(id)/(\d+)/$', views.getNode),
    url(r'^api/get/node/(name)/(.+)/$', views.getNode),

    url(r'^api/get/neighborhoods/(id)/(\d+)/$', views.getNeigh),
    url(r'^api/get/neighborhoods/$', views.getNeighborhoods),
    url(r'^api/get/neighborhoodsType/id/(\d+)/$', views.getNeighborType),
    
    url(r'^api/get/edge/(.+)/(.+)/$', views.getEdge),
    
    url(r'^api/get/commonAdjacent/$', views.commonAdjacent),
    
    url(r'^api/get/instance/$', views.getInstance),
    
    url(r'^api/post/addNode/$', views.addNode),
    url(r'^api/post/addEdge/$', views.addEdge),

    url(r'^api/post/dropNode/id/(\d+)/$', views.dropNode),
    url(r'^api/post/dropEdge/id/(.+)/$', views.dropEdge),
    
    url(r'^api/get/groupCount/(.+)/$', views.groupCount),
    url(r'^api/post/switchGraph/(.+)/$', views.switchGraph),
]
